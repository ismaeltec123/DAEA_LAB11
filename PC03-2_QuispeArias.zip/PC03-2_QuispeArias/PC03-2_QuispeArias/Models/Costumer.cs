﻿namespace PC03_2_QuispeArias.Models
{
    public class Customer
    {
        // Llave primaria
        public int CustomerId { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DocumentNumber { get; set; }

        // Propiedad de navegación 
        public ICollection<Invoice> Invoices { get; set; } = new List<Invoice>();
    }
}

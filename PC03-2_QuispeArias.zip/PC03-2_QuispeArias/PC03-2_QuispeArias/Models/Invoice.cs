﻿namespace PC03_2_QuispeArias.Models
{
    public class Invoice
    {
        // Llave primaria
        public int InvoiceId { get; set; }

        public DateTime Date { get; set; }

        // Llave foránea
        public int CustomerId { get; set; }

        // Propiedad de navegación
        public Customer Customer { get; set; }
    }
}

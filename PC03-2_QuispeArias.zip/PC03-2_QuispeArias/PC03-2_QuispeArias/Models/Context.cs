﻿using Microsoft.EntityFrameworkCore;
using PC03_2_QuispeArias.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace PC03_2_QuispeArias.Models
{
    public class Context : DbContext
    {
        public Context(DbContextOptions<Context> options) : base(options)
        {
        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Invoice> Invoices { get; set; }

       
    }
}
